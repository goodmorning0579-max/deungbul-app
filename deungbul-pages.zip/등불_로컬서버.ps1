# 등불 로컬 서버 (PowerShell 내장 기능만 사용, 별도 설치 불필요)
# 이 폴더를 http://localhost:8080 으로 서빙합니다.

$port = 8080
$root = $PSScriptRoot
$url = "http://localhost:$port/"

Add-Type -AssemblyName System.Net.HttpListener -ErrorAction SilentlyContinue

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

try {
    $listener.Start()
} catch {
    Write-Host ""
    Write-Host "포트 $port 를 사용할 수 없습니다. 이미 실행 중이거나 다른 프로그램이 사용 중일 수 있습니다." -ForegroundColor Yellow
    Write-Host "잠시 후 다시 시도하거나, 창을 닫고 다시 더블클릭 해보세요." -ForegroundColor Yellow
    Read-Host "아무 키나 눌러 종료하세요"
    exit
}

Write-Host ""
Write-Host "===================================================" -ForegroundColor DarkYellow
Write-Host "  등불 로컬 서버가 시작되었습니다" -ForegroundColor Yellow
Write-Host "===================================================" -ForegroundColor DarkYellow
Write-Host ""
Write-Host "  주소: $url" -ForegroundColor Cyan
Write-Host "  이 창을 닫으면 서버도 함께 종료됩니다." -ForegroundColor Gray
Write-Host "  (브라우저는 자동으로 열립니다. 열리지 않으면 위 주소를 직접 입력하세요)" -ForegroundColor Gray
Write-Host ""

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".png"  = "image/png"
    ".ico"  = "image/x-icon"
    ".svg"  = "image/svg+xml"
    ".webmanifest" = "application/manifest+json"
}

# 브라우저 자동 열기 (index.html 우선, 없으면 mobile.html)
$startPage = "index.html"
if (-not (Test-Path (Join-Path $root "index.html"))) {
    if (Test-Path (Join-Path $root "mobile.html")) { $startPage = "mobile.html" }
    elseif (Test-Path (Join-Path $root "desktop.html")) { $startPage = "desktop.html" }
}
Start-Process ($url + $startPage)

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $localPath = [System.Uri]::UnescapeDataString($request.Url.LocalPath)
        if ($localPath -eq "/") { $localPath = "/$startPage" }
        $filePath = Join-Path $root ($localPath.TrimStart("/"))

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $contentType = $mimeTypes[$ext]
            if (-not $contentType) { $contentType = "application/octet-stream" }
            $response.ContentType = $contentType
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $notFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.OutputStream.Write($notFound, 0, $notFound.Length)
        }
        $response.OutputStream.Close()
    } catch {
        # 창이 닫히면 여기로 빠져나옴
        break
    }
}

$listener.Stop()
