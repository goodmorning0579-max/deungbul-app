@echo off
chcp 65001 >nul
title 등불 로컬 서버
echo.
echo   등불 로컬 서버를 시작합니다...
echo   (파이썬 등 별도 설치 없이 Windows 기본 기능만 사용합니다)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0등불_로컬서버.ps1"
pause
