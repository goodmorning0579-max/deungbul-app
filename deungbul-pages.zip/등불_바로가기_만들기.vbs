' 등불 바로가기 만들기 (Windows) — 자동 감지 개선판
' 사용법: 등불 HTML 파일과 이 .vbs 파일을 같은 폴더에 두고 더블클릭하세요.
'         같은 폴더에서 HTML 파일을 자동으로 찾아 바탕화면에 아이콘 바로가기를 만듭니다.
'         (자동으로 못 찾으면 직접 경로를 입력하는 창이 뜹니다.)

Dim objShell, objFSO, targetFile, iconFile, desktopPath, shortcutPath
Dim objShortcut, folder, file, found

Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

scriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
iconFile = scriptDir & "\favicon.ico"

' 1) 같은 폴더에서 "등불"이 들어간 .html 파일 자동 검색
targetFile = ""
Set folder = objFSO.GetFolder(scriptDir)
For Each file In folder.Files
    If LCase(objFSO.GetExtensionName(file.Name)) = "html" Then
        If InStr(file.Name, "등불") > 0 Then
            targetFile = file.Path
            Exit For
        End If
    End If
Next

' 2) 자동으로 못 찾았으면 수동 입력 요청
If targetFile = "" Then
    targetFile = InputBox( _
        "같은 폴더에서 등불 HTML 파일을 자동으로 찾지 못했습니다." & vbCrLf & vbCrLf & _
        "등불 HTML 파일의 전체 경로를 입력(또는 붙여넣기)하세요." & vbCrLf & vbCrLf & _
        "예: C:\Users\사용자이름\Downloads\등불_데스크탑_통합판.html" & vbCrLf & vbCrLf & _
        "* 파일 탐색기에서 해당 파일 우클릭 > '경로로 복사'로 쉽게 붙여넣을 수 있습니다.", _
        "등불 바로가기 만들기")
    If targetFile = "" Then WScript.Quit
    targetFile = Replace(targetFile, Chr(34), "")
End If

If Not objFSO.FileExists(targetFile) Then
    MsgBox "해당 경로에서 파일을 찾을 수 없습니다:" & vbCrLf & targetFile, vbExclamation, "등불"
    WScript.Quit
End If

desktopPath = objShell.SpecialFolders("Desktop")
shortcutPath = desktopPath & "\등불.lnk"

Set objShortcut = objShell.CreateShortcut(shortcutPath)
objShortcut.TargetPath = targetFile
objShortcut.WorkingDirectory = objFSO.GetParentFolderName(targetFile)
objShortcut.Description = "등불 - 성경연구 앱 (시편 119:105)"

If objFSO.FileExists(iconFile) Then
    objShortcut.IconLocation = iconFile & ",0"
End If

objShortcut.Save

MsgBox "바탕화면에 '등불' 바로가기가 생성되었습니다!" & vbCrLf & vbCrLf & _
       "연결된 파일: " & targetFile & vbCrLf & vbCrLf & _
       "이제부터 바탕화면 아이콘을 더블클릭하면 바로 등불 앱이 열립니다.", _
       vbInformation, "등불 바로가기 생성 완료"
