' 등불 로컬 서버 시작 (Windows, 파이썬/추가설치 불필요)
' 이 파일 하나만 있으면 됩니다. 실행하면 같은 폴더에 서버 스크립트를 자동으로
' 만들고 바로 실행합니다. (내부적으로 PowerShell을 사용합니다.)

Dim objFSO, objShell, scriptDir, ps1Path, ps1Content

Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objShell = CreateObject("WScript.Shell")

scriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
ps1Path = scriptDir & "\등불_로컬서버_자동생성.ps1"

ps1Content = ""
    ps1Content = ps1Content & "# 등불 로컬 서버 (PowerShell 내장 기능만 사용, 별도 설치 불필요)" & vbCrLf
    ps1Content = ps1Content & "# 이 폴더를 http://localhost:8080 으로 서빙합니다." & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "$port = 8080" & vbCrLf
    ps1Content = ps1Content & "$root = $PSScriptRoot" & vbCrLf
    ps1Content = ps1Content & "$url = ""http://localhost:$port/""" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "Add-Type -AssemblyName System.Net.HttpListener -ErrorAction SilentlyContinue" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "$listener = New-Object System.Net.HttpListener" & vbCrLf
    ps1Content = ps1Content & "$listener.Prefixes.Add($url)" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "try {" & vbCrLf
    ps1Content = ps1Content & "    $listener.Start()" & vbCrLf
    ps1Content = ps1Content & "} catch {" & vbCrLf
    ps1Content = ps1Content & "    Write-Host """"" & vbCrLf
    ps1Content = ps1Content & "    Write-Host ""포트 $port 를 사용할 수 없습니다. 이미 실행 중이거나 다른 프로그램이 사용 중일 수 있습니다."" -ForegroundColor Yellow" & vbCrLf
    ps1Content = ps1Content & "    Write-Host ""잠시 후 다시 시도하거나, 창을 닫고 다시 더블클릭 해보세요."" -ForegroundColor Yellow" & vbCrLf
    ps1Content = ps1Content & "    Read-Host ""아무 키나 눌러 종료하세요""" & vbCrLf
    ps1Content = ps1Content & "    exit" & vbCrLf
    ps1Content = ps1Content & "}" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "Write-Host """"" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""==================================================="" -ForegroundColor DarkYellow" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""  등불 로컬 서버가 시작되었습니다"" -ForegroundColor Yellow" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""==================================================="" -ForegroundColor DarkYellow" & vbCrLf
    ps1Content = ps1Content & "Write-Host """"" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""  주소: $url"" -ForegroundColor Cyan" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""  이 창을 닫으면 서버도 함께 종료됩니다."" -ForegroundColor Gray" & vbCrLf
    ps1Content = ps1Content & "Write-Host ""  (브라우저는 자동으로 열립니다. 열리지 않으면 위 주소를 직접 입력하세요)"" -ForegroundColor Gray" & vbCrLf
    ps1Content = ps1Content & "Write-Host """"" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "$mimeTypes = @{" & vbCrLf
    ps1Content = ps1Content & "    "".html"" = ""text/html; charset=utf-8""" & vbCrLf
    ps1Content = ps1Content & "    "".htm""  = ""text/html; charset=utf-8""" & vbCrLf
    ps1Content = ps1Content & "    "".json"" = ""application/json; charset=utf-8""" & vbCrLf
    ps1Content = ps1Content & "    "".js""   = ""application/javascript; charset=utf-8""" & vbCrLf
    ps1Content = ps1Content & "    "".css""  = ""text/css; charset=utf-8""" & vbCrLf
    ps1Content = ps1Content & "    "".png""  = ""image/png""" & vbCrLf
    ps1Content = ps1Content & "    "".ico""  = ""image/x-icon""" & vbCrLf
    ps1Content = ps1Content & "    "".svg""  = ""image/svg+xml""" & vbCrLf
    ps1Content = ps1Content & "    "".webmanifest"" = ""application/manifest+json""" & vbCrLf
    ps1Content = ps1Content & "}" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "# 브라우저 자동 열기 (index.html 우선, 없으면 mobile.html)" & vbCrLf
    ps1Content = ps1Content & "$startPage = ""index.html""" & vbCrLf
    ps1Content = ps1Content & "if (-not (Test-Path (Join-Path $root ""index.html""))) {" & vbCrLf
    ps1Content = ps1Content & "    if (Test-Path (Join-Path $root ""mobile.html"")) { $startPage = ""mobile.html"" }" & vbCrLf
    ps1Content = ps1Content & "    elseif (Test-Path (Join-Path $root ""desktop.html"")) { $startPage = ""desktop.html"" }" & vbCrLf
    ps1Content = ps1Content & "}" & vbCrLf
    ps1Content = ps1Content & "Start-Process ($url + $startPage)" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "while ($listener.IsListening) {" & vbCrLf
    ps1Content = ps1Content & "    try {" & vbCrLf
    ps1Content = ps1Content & "        $context = $listener.GetContext()" & vbCrLf
    ps1Content = ps1Content & "        $request = $context.Request" & vbCrLf
    ps1Content = ps1Content & "        $response = $context.Response" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "        $localPath = [System.Uri]::UnescapeDataString($request.Url.LocalPath)" & vbCrLf
    ps1Content = ps1Content & "        if ($localPath -eq ""/"") { $localPath = ""/$startPage"" }" & vbCrLf
    ps1Content = ps1Content & "        $filePath = Join-Path $root ($localPath.TrimStart(""/""))" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "        if (Test-Path $filePath -PathType Leaf) {" & vbCrLf
    ps1Content = ps1Content & "            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()" & vbCrLf
    ps1Content = ps1Content & "            $contentType = $mimeTypes[$ext]" & vbCrLf
    ps1Content = ps1Content & "            if (-not $contentType) { $contentType = ""application/octet-stream"" }" & vbCrLf
    ps1Content = ps1Content & "            $response.ContentType = $contentType" & vbCrLf
    ps1Content = ps1Content & "            $bytes = [System.IO.File]::ReadAllBytes($filePath)" & vbCrLf
    ps1Content = ps1Content & "            $response.ContentLength64 = $bytes.Length" & vbCrLf
    ps1Content = ps1Content & "            $response.OutputStream.Write($bytes, 0, $bytes.Length)" & vbCrLf
    ps1Content = ps1Content & "        } else {" & vbCrLf
    ps1Content = ps1Content & "            $response.StatusCode = 404" & vbCrLf
    ps1Content = ps1Content & "            $notFound = [System.Text.Encoding]::UTF8.GetBytes(""404 Not Found"")" & vbCrLf
    ps1Content = ps1Content & "            $response.OutputStream.Write($notFound, 0, $notFound.Length)" & vbCrLf
    ps1Content = ps1Content & "        }" & vbCrLf
    ps1Content = ps1Content & "        $response.OutputStream.Close()" & vbCrLf
    ps1Content = ps1Content & "    } catch {" & vbCrLf
    ps1Content = ps1Content & "        # 창이 닫히면 여기로 빠져나옴" & vbCrLf
    ps1Content = ps1Content & "        break" & vbCrLf
    ps1Content = ps1Content & "    }" & vbCrLf
    ps1Content = ps1Content & "}" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf
    ps1Content = ps1Content & "$listener.Stop()" & vbCrLf
    ps1Content = ps1Content & "" & vbCrLf

Dim ts
Set ts = objFSO.CreateTextFile(ps1Path, True, True) ' True = Unicode(UTF-16)
ts.Write ps1Content
ts.Close

objShell.Run "powershell -NoProfile -ExecutionPolicy Bypass -File """ & ps1Path & """", 1, False
